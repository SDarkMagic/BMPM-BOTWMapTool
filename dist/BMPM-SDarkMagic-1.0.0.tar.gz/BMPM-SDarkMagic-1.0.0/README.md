# BMPM
 A script for manipulating parameters contained within BotW's map files in bulk.

# Installation
 Copy the ".exe" file to C:/Users/(username)/AppData/local/Programs/Python/scripts/ OR add the directory containing the compiled script to your PATH

# Usage
 The batch file included is for recursively going through directories and editing all "LevelSensorMode" parameters to 1
 For more information on how to use the script, type "bymlMapParamEditor -h" or "bymlMapParamEditor --help"
